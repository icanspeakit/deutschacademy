repo: icanspeakit/deutschacademy
branch: main

## Last sync
date: 2026-09-04T16:03:11Z
### Updated in this project
- Built learner dashboard + lesson prototype (2 layout options) in the DeutschAcademy brand style
- Artikel-Trainer lesson uses nouns from src/data/artikel.json
- Wortschatz flashcards use phrases from src/data/wortschatz.json; flow mirrors src/lib/learn.js
- Copied two candid photos from public/assets

## Screen map
| Screen | Repo files |
| --- | --- |
| DeutschAcademy Dashboard.dc.html · 1a dashboard + Artikel-Trainer | src/data/artikel.json, src/lib/quiz.js, public/assets/foto-buero-1.jpg, public/assets/man-1209494_1280.jpg |
| DeutschAcademy Dashboard.dc.html · 1b dashboard + Wortschatz-Karten | src/data/wortschatz.json, src/lib/learn.js, public/assets/foto-buero-1.jpg, public/assets/man-1209494_1280.jpg |
